NOTE: This folder contains generated versions of Minecraft Bedrock Edition and Minecraft Bedrock Edition Vanilla Content metadata.

The formats of these JSON files are subject to change, so please avoid taking any significant dependencies on the structure of these JSON files.