// Import required modules
const Minecraft = require('mojang-minecraft');

// Get the server instance
const server = Minecraft.server;

// Listen for chat messages
server.on('chat', (eventData) => {
    let message = eventData.message;
    if (message === "your specific message") {
        let playerName = eventData.sender.name;
        server.executeCommand(`/tp ${playerName} x y z`);
    }
});
